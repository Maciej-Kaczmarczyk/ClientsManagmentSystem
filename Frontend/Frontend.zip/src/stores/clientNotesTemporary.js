export const clientNotes = [
    {
      id: 1,
      title: "Note 1",
      content: "This is note 1",
      date: "2023-12-07",
    },
    {
      id: 2,
      title: "Note 2",
      content: "This is note 2",
      date: "2023-12-01",
    },
    {
      id: 3,
      title: "Note 3",
      content: "This is note 3",
      date: "2023-11-06",
    }
  ];