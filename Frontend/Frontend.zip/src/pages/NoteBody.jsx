import React from "react";

const NoteBody = () => {
  return <div>Note content</div>;
};

export default NoteBody;
